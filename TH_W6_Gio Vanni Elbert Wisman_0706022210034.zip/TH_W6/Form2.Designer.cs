﻿namespace TH_W6
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonQ = new System.Windows.Forms.Button();
            this.buttonW = new System.Windows.Forms.Button();
            this.buttonY = new System.Windows.Forms.Button();
            this.buttonT = new System.Windows.Forms.Button();
            this.buttonR = new System.Windows.Forms.Button();
            this.buttonE = new System.Windows.Forms.Button();
            this.buttonU = new System.Windows.Forms.Button();
            this.buttonO = new System.Windows.Forms.Button();
            this.buttonP = new System.Windows.Forms.Button();
            this.buttoni = new System.Windows.Forms.Button();
            this.buttonH = new System.Windows.Forms.Button();
            this.buttonA = new System.Windows.Forms.Button();
            this.buttonJ = new System.Windows.Forms.Button();
            this.buttonS = new System.Windows.Forms.Button();
            this.buttonK = new System.Windows.Forms.Button();
            this.buttonD = new System.Windows.Forms.Button();
            this.buttonL = new System.Windows.Forms.Button();
            this.buttonF = new System.Windows.Forms.Button();
            this.buttonEnter = new System.Windows.Forms.Button();
            this.buttonG = new System.Windows.Forms.Button();
            this.buttonM = new System.Windows.Forms.Button();
            this.buttonN = new System.Windows.Forms.Button();
            this.buttonB = new System.Windows.Forms.Button();
            this.buttonC = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.buttonV = new System.Windows.Forms.Button();
            this.buttonZ = new System.Windows.Forms.Button();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonQ
            // 
            this.buttonQ.Location = new System.Drawing.Point(465, 113);
            this.buttonQ.Name = "buttonQ";
            this.buttonQ.Size = new System.Drawing.Size(51, 48);
            this.buttonQ.TabIndex = 1;
            this.buttonQ.Text = "Q";
            this.buttonQ.UseVisualStyleBackColor = true;
            this.buttonQ.Click += new System.EventHandler(this.buttonQ_Click);
            // 
            // buttonW
            // 
            this.buttonW.Location = new System.Drawing.Point(522, 113);
            this.buttonW.Name = "buttonW";
            this.buttonW.Size = new System.Drawing.Size(49, 48);
            this.buttonW.TabIndex = 2;
            this.buttonW.Text = "W";
            this.buttonW.UseVisualStyleBackColor = true;
            this.buttonW.Click += new System.EventHandler(this.buttonW_Click);
            // 
            // buttonY
            // 
            this.buttonY.Location = new System.Drawing.Point(736, 115);
            this.buttonY.Name = "buttonY";
            this.buttonY.Size = new System.Drawing.Size(44, 48);
            this.buttonY.TabIndex = 7;
            this.buttonY.Text = "Y";
            this.buttonY.UseVisualStyleBackColor = true;
            this.buttonY.Click += new System.EventHandler(this.buttonY_Click);
            // 
            // buttonT
            // 
            this.buttonT.Location = new System.Drawing.Point(685, 115);
            this.buttonT.Name = "buttonT";
            this.buttonT.Size = new System.Drawing.Size(45, 48);
            this.buttonT.TabIndex = 8;
            this.buttonT.Text = "T";
            this.buttonT.UseVisualStyleBackColor = true;
            this.buttonT.Click += new System.EventHandler(this.buttonT_Click);
            // 
            // buttonR
            // 
            this.buttonR.Location = new System.Drawing.Point(632, 113);
            this.buttonR.Name = "buttonR";
            this.buttonR.Size = new System.Drawing.Size(47, 48);
            this.buttonR.TabIndex = 9;
            this.buttonR.Text = "R";
            this.buttonR.UseVisualStyleBackColor = true;
            this.buttonR.Click += new System.EventHandler(this.buttonR_Click);
            // 
            // buttonE
            // 
            this.buttonE.Location = new System.Drawing.Point(577, 113);
            this.buttonE.Name = "buttonE";
            this.buttonE.Size = new System.Drawing.Size(49, 48);
            this.buttonE.TabIndex = 10;
            this.buttonE.Text = "E";
            this.buttonE.UseVisualStyleBackColor = true;
            this.buttonE.Click += new System.EventHandler(this.buttonE_Click);
            // 
            // buttonU
            // 
            this.buttonU.Location = new System.Drawing.Point(793, 115);
            this.buttonU.Name = "buttonU";
            this.buttonU.Size = new System.Drawing.Size(44, 48);
            this.buttonU.TabIndex = 11;
            this.buttonU.Text = "U";
            this.buttonU.UseVisualStyleBackColor = true;
            this.buttonU.Click += new System.EventHandler(this.buttonU_Click);
            // 
            // buttonO
            // 
            this.buttonO.Location = new System.Drawing.Point(905, 115);
            this.buttonO.Name = "buttonO";
            this.buttonO.Size = new System.Drawing.Size(44, 48);
            this.buttonO.TabIndex = 12;
            this.buttonO.Text = "O";
            this.buttonO.UseVisualStyleBackColor = true;
            this.buttonO.Click += new System.EventHandler(this.buttonO_Click);
            // 
            // buttonP
            // 
            this.buttonP.Location = new System.Drawing.Point(962, 115);
            this.buttonP.Name = "buttonP";
            this.buttonP.Size = new System.Drawing.Size(44, 48);
            this.buttonP.TabIndex = 13;
            this.buttonP.Text = "P";
            this.buttonP.UseVisualStyleBackColor = true;
            this.buttonP.Click += new System.EventHandler(this.buttonP_Click);
            // 
            // buttoni
            // 
            this.buttoni.Location = new System.Drawing.Point(850, 115);
            this.buttoni.Name = "buttoni";
            this.buttoni.Size = new System.Drawing.Size(44, 48);
            this.buttoni.TabIndex = 14;
            this.buttoni.Text = "I";
            this.buttoni.UseVisualStyleBackColor = true;
            this.buttoni.Click += new System.EventHandler(this.buttoni_Click);
            // 
            // buttonH
            // 
            this.buttonH.Location = new System.Drawing.Point(765, 169);
            this.buttonH.Name = "buttonH";
            this.buttonH.Size = new System.Drawing.Size(51, 48);
            this.buttonH.TabIndex = 15;
            this.buttonH.Text = "H";
            this.buttonH.UseVisualStyleBackColor = true;
            this.buttonH.Click += new System.EventHandler(this.buttonH_Click);
            // 
            // buttonA
            // 
            this.buttonA.Location = new System.Drawing.Point(480, 169);
            this.buttonA.Name = "buttonA";
            this.buttonA.Size = new System.Drawing.Size(51, 48);
            this.buttonA.TabIndex = 15;
            this.buttonA.Text = "A";
            this.buttonA.UseVisualStyleBackColor = true;
            this.buttonA.Click += new System.EventHandler(this.buttonA_Click);
            // 
            // buttonJ
            // 
            this.buttonJ.Location = new System.Drawing.Point(822, 169);
            this.buttonJ.Name = "buttonJ";
            this.buttonJ.Size = new System.Drawing.Size(51, 48);
            this.buttonJ.TabIndex = 15;
            this.buttonJ.Text = "J";
            this.buttonJ.UseVisualStyleBackColor = true;
            this.buttonJ.Click += new System.EventHandler(this.buttonJ_Click);
            // 
            // buttonS
            // 
            this.buttonS.Location = new System.Drawing.Point(537, 169);
            this.buttonS.Name = "buttonS";
            this.buttonS.Size = new System.Drawing.Size(51, 48);
            this.buttonS.TabIndex = 15;
            this.buttonS.Text = "S";
            this.buttonS.UseVisualStyleBackColor = true;
            this.buttonS.Click += new System.EventHandler(this.buttonS_Click);
            // 
            // buttonK
            // 
            this.buttonK.Location = new System.Drawing.Point(877, 169);
            this.buttonK.Name = "buttonK";
            this.buttonK.Size = new System.Drawing.Size(51, 48);
            this.buttonK.TabIndex = 15;
            this.buttonK.Text = "K";
            this.buttonK.UseVisualStyleBackColor = true;
            this.buttonK.Click += new System.EventHandler(this.buttonK_Click);
            // 
            // buttonD
            // 
            this.buttonD.Location = new System.Drawing.Point(594, 169);
            this.buttonD.Name = "buttonD";
            this.buttonD.Size = new System.Drawing.Size(51, 48);
            this.buttonD.TabIndex = 15;
            this.buttonD.Text = "D";
            this.buttonD.UseVisualStyleBackColor = true;
            this.buttonD.Click += new System.EventHandler(this.buttonD_Click);
            // 
            // buttonL
            // 
            this.buttonL.Location = new System.Drawing.Point(934, 169);
            this.buttonL.Name = "buttonL";
            this.buttonL.Size = new System.Drawing.Size(51, 48);
            this.buttonL.TabIndex = 15;
            this.buttonL.Text = "L";
            this.buttonL.UseVisualStyleBackColor = true;
            this.buttonL.Click += new System.EventHandler(this.buttonL_Click);
            // 
            // buttonF
            // 
            this.buttonF.Location = new System.Drawing.Point(651, 169);
            this.buttonF.Name = "buttonF";
            this.buttonF.Size = new System.Drawing.Size(51, 48);
            this.buttonF.TabIndex = 15;
            this.buttonF.Text = "F";
            this.buttonF.UseVisualStyleBackColor = true;
            this.buttonF.Click += new System.EventHandler(this.buttonF_Click);
            // 
            // buttonEnter
            // 
            this.buttonEnter.Location = new System.Drawing.Point(448, 235);
            this.buttonEnter.Name = "buttonEnter";
            this.buttonEnter.Size = new System.Drawing.Size(83, 48);
            this.buttonEnter.TabIndex = 15;
            this.buttonEnter.Text = "Enter";
            this.buttonEnter.UseVisualStyleBackColor = true;
            this.buttonEnter.Click += new System.EventHandler(this.buttonEnter_Click);
            // 
            // buttonG
            // 
            this.buttonG.Location = new System.Drawing.Point(708, 169);
            this.buttonG.Name = "buttonG";
            this.buttonG.Size = new System.Drawing.Size(51, 48);
            this.buttonG.TabIndex = 15;
            this.buttonG.Text = "G";
            this.buttonG.UseVisualStyleBackColor = true;
            this.buttonG.Click += new System.EventHandler(this.buttonG_Click);
            // 
            // buttonM
            // 
            this.buttonM.Location = new System.Drawing.Point(879, 235);
            this.buttonM.Name = "buttonM";
            this.buttonM.Size = new System.Drawing.Size(51, 48);
            this.buttonM.TabIndex = 18;
            this.buttonM.Text = "M";
            this.buttonM.UseVisualStyleBackColor = true;
            this.buttonM.Click += new System.EventHandler(this.buttonM_Click);
            // 
            // buttonN
            // 
            this.buttonN.Location = new System.Drawing.Point(822, 235);
            this.buttonN.Name = "buttonN";
            this.buttonN.Size = new System.Drawing.Size(51, 48);
            this.buttonN.TabIndex = 20;
            this.buttonN.Text = "N";
            this.buttonN.UseVisualStyleBackColor = true;
            this.buttonN.Click += new System.EventHandler(this.buttonN_Click);
            // 
            // buttonB
            // 
            this.buttonB.Location = new System.Drawing.Point(765, 235);
            this.buttonB.Name = "buttonB";
            this.buttonB.Size = new System.Drawing.Size(51, 48);
            this.buttonB.TabIndex = 21;
            this.buttonB.Text = "B";
            this.buttonB.UseVisualStyleBackColor = true;
            this.buttonB.Click += new System.EventHandler(this.buttonB_Click);
            // 
            // buttonC
            // 
            this.buttonC.Location = new System.Drawing.Point(651, 235);
            this.buttonC.Name = "buttonC";
            this.buttonC.Size = new System.Drawing.Size(51, 48);
            this.buttonC.TabIndex = 22;
            this.buttonC.Text = "C";
            this.buttonC.UseVisualStyleBackColor = true;
            this.buttonC.Click += new System.EventHandler(this.buttonC_Click);
            // 
            // buttonX
            // 
            this.buttonX.Location = new System.Drawing.Point(594, 235);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(51, 48);
            this.buttonX.TabIndex = 23;
            this.buttonX.Text = "X";
            this.buttonX.UseVisualStyleBackColor = true;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            // 
            // buttonV
            // 
            this.buttonV.Location = new System.Drawing.Point(708, 235);
            this.buttonV.Name = "buttonV";
            this.buttonV.Size = new System.Drawing.Size(51, 48);
            this.buttonV.TabIndex = 24;
            this.buttonV.Text = "V";
            this.buttonV.UseVisualStyleBackColor = true;
            this.buttonV.Click += new System.EventHandler(this.buttonV_Click);
            // 
            // buttonZ
            // 
            this.buttonZ.Location = new System.Drawing.Point(537, 235);
            this.buttonZ.Name = "buttonZ";
            this.buttonZ.Size = new System.Drawing.Size(51, 48);
            this.buttonZ.TabIndex = 25;
            this.buttonZ.Text = "Z";
            this.buttonZ.UseVisualStyleBackColor = true;
            this.buttonZ.Click += new System.EventHandler(this.buttonZ_Click);
            // 
            // buttonDelete
            // 
            this.buttonDelete.Location = new System.Drawing.Point(936, 235);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(83, 48);
            this.buttonDelete.TabIndex = 26;
            this.buttonDelete.Text = "Delete";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1056, 531);
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.buttonV);
            this.Controls.Add(this.buttonZ);
            this.Controls.Add(this.buttonC);
            this.Controls.Add(this.buttonX);
            this.Controls.Add(this.buttonN);
            this.Controls.Add(this.buttonB);
            this.Controls.Add(this.buttonM);
            this.Controls.Add(this.buttonG);
            this.Controls.Add(this.buttonF);
            this.Controls.Add(this.buttonD);
            this.Controls.Add(this.buttonS);
            this.Controls.Add(this.buttonEnter);
            this.Controls.Add(this.buttonL);
            this.Controls.Add(this.buttonK);
            this.Controls.Add(this.buttonJ);
            this.Controls.Add(this.buttonA);
            this.Controls.Add(this.buttonH);
            this.Controls.Add(this.buttoni);
            this.Controls.Add(this.buttonP);
            this.Controls.Add(this.buttonO);
            this.Controls.Add(this.buttonU);
            this.Controls.Add(this.buttonE);
            this.Controls.Add(this.buttonR);
            this.Controls.Add(this.buttonT);
            this.Controls.Add(this.buttonY);
            this.Controls.Add(this.buttonW);
            this.Controls.Add(this.buttonQ);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonQ;
        private System.Windows.Forms.Button buttonW;
        private System.Windows.Forms.Button buttonY;
        private System.Windows.Forms.Button buttonT;
        private System.Windows.Forms.Button buttonR;
        private System.Windows.Forms.Button buttonE;
        private System.Windows.Forms.Button buttonU;
        private System.Windows.Forms.Button buttonO;
        private System.Windows.Forms.Button buttonP;
        private System.Windows.Forms.Button buttoni;
        private System.Windows.Forms.Button buttonH;
        private System.Windows.Forms.Button buttonA;
        private System.Windows.Forms.Button buttonJ;
        private System.Windows.Forms.Button buttonS;
        private System.Windows.Forms.Button buttonK;
        private System.Windows.Forms.Button buttonD;
        private System.Windows.Forms.Button buttonL;
        private System.Windows.Forms.Button buttonF;
        private System.Windows.Forms.Button buttonEnter;
        private System.Windows.Forms.Button buttonG;
        private System.Windows.Forms.Button buttonM;
        private System.Windows.Forms.Button buttonN;
        private System.Windows.Forms.Button buttonB;
        private System.Windows.Forms.Button buttonC;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.Button buttonV;
        private System.Windows.Forms.Button buttonZ;
        private System.Windows.Forms.Button buttonDelete;
    }
}